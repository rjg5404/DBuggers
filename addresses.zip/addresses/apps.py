from django.apps import AppConfig


class AddressesConfig(AppConfig):
    name = 'addresses'
